import React from "react";
import Meals from "./Components/Meals";
import RecipeReviewCard from "./Components/MealCard"
import BasicModal from "../src/Components/Modal"
function App() {

  return (
    <>
      
        {/* <Meals /> */}
        <RecipeReviewCard />
        <BasicModal></BasicModal>
    </>
  )
}

export default App;